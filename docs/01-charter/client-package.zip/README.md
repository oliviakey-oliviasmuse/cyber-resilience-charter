﻿# Cyber Resilience Project Charter — Client Package
**Phase 1 (Define) | Six Sigma Aligned | Z ≥ 6.0 Target**

## Contents

This package contains the final Phase 1 (Define) deliverable for the CISO G1 review. Four files:

| # | File | Size | Purpose |
|---|---|---|---|
| 1 | `Cyber-Resilience-Project-Charter.docx` | ~100 KB | Editable Word document — primary deliverable for the CISO meeting |
| 2 | `Cyber-Resilience-Project-Charter.pdf` | ~4.9 MB | Read-only PDF for distribution, email, share, print |
| 3 | `cyber-resilience-charter.html` | ~240 KB | Self-contained HTML bundle with embedded CISO dashboard; opens in any browser |
| 4 | `ciso-dashboard-mockup.html` | ~44 KB | Standalone interactive CISO Executive Dashboard (8 tiles, click-to-drill-down) |

## Public URLs (Six Sigma-aligned, G5 illustrative state)

- Full charter (8 sections + 2 appendices + embedded dashboard): https://87x1siaib1okk.space.minimax.io
- Standalone CISO dashboard: https://6z9fkk0oehsun.space.minimax.io
- Standalone CISO dashboard (additional deployment): https://vmn4dy5p05641.space.minimax.io

## Confidentiality

CONFIDENTIAL — CISO EYES ONLY. Anonymised per the data-access protocol (§3.5 of the charter). Internal network configurations, IP addresses, hostnames, and proprietary system details are protected.

## Engagement Summary

- **Objective:** Zero production downtime from cyber attacks and viruses in global EV cell manufacturing
- **Methodology:** Lean Six Sigma Master Black Belt (MBB) / DMAIC
- **Capability target:** Z ≥ 6.0 (theoretical Six Sigma, 0.002 DPMO short-term / 3.4 DPMO with 1.5σ long-term shift)
- **Exposure band:** $20M–$180M+ per year per department (3–11× the OSI entropy framework)
- **5-site enterprise protected value:** $25M–$225M+ per year (conservative capture M=25%)
- **Team:** 19 Senior Software Engineers (Green Belts) at 10% weekly capacity
- **Duration:** 12 weeks, 5 tollgates (G1–G5)

## Dashboard Interaction

The HTML files include the interactive CISO Executive Dashboard with 8 tiles. Click any tile to open a drill-down modal with sub-metrics, time trends, AI agent status, FMEA details. The dashboard is mobile-responsive and works on tablet/phone.